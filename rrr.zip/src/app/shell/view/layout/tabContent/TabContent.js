import React from "react";
import classes from "./TabContent.module.css"


const TabContent = props => {
    return <div className={classes.TabContent}>
        <div className={classes.TabBody}>

        </div>

    </div>

}

export default TabContent;