import logo from '../logo.svg';
import './App.css';
import classes from "./App.css"
import Shell from "./shell/Shell";

function App() {
  return (
    <>
      <Shell/>
    </>
  );
}

export default App;
